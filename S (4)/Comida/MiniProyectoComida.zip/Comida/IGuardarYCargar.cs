﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControlVentas
{
    interface IGuardarYCargar
    {
        void Guardar();
        void Cargar();
    }
}
