﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ControlVentas;

namespace Hospital
{
    public class CPaciente : CPersona
    {
        #region Private Variables
        public string razon { get; private set; }
        public ETipoDeSangre sangre { get; private set; }
        public string sangreS { get; private set; }
        #endregion

        #region Constructors
        public CPaciente(string nombre, string apellido, string razon, ETipoDeSangre sangre)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.razon = razon;
            this.sangre = sangre;
            this.sangreS = CUtilities.StringValueOf(sangre);
        }
        #endregion

        #region Public Methods
        public string GetRazon()
        {
            return this.razon;
        }

        public void SetRazon(string s)
        {
            this.razon = s;
        }

        public ETipoDeSangre GetSangre()
        {
            return this.sangre;
        }

        public void SetSangre(ETipoDeSangre s)
        {
            this.sangre = s;
        }

        public string GetSangreAsString()
        {
            return this.sangreS;
        }

        public string ToSaveString()
        {
            return nombre + "$" + apellido + "$" + razon + "$" + (int)sangre + "$";
        }
        #endregion
    }
}
