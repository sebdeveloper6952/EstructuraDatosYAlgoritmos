var searchData=
[
  ['fullstackexception',['FullStackException',['../class_operaciones_pila_1_1_full_stack_exception.html',1,'OperacionesPila']]]
];
