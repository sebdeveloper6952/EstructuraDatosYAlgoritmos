﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ControlVentas;
using System.IO;

namespace Comida
{
    public class CAdminMenu : IGuardarYCargar
    {
        private List<CItem> items;

        public CAdminMenu()
        {
            items = new List<CItem>();
        }

        public List<CItem> GetItems() { return this.items; }

        public void AddItem(CItem item) { items.Add(item); }

        public CItem GetItem(int index) { return items[index]; }

        public void Guardar()
        {
            StreamWriter sw = File.CreateText("menu.txt");
            foreach(CItem i in items)
            {
                sw.WriteLine(i.ToSavingFormat());
            }
            sw.Flush();
            sw.Close();
        }

        public void Cargar()
        {
            if (File.Exists("menu.txt"))
            {
                string[] lines = File.ReadAllLines("menu.txt");
                foreach (string line in lines)
                {
                    string[] item = line.Split('$');
                    string nombre = item[0];
                    float precio = float.Parse(item[1]);
                    CItem i = new CItem(nombre, null, precio);
                    items.Add(i);
                }
            }
        }
    }
}
