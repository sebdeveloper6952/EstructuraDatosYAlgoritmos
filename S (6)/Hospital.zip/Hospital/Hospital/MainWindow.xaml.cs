﻿using System;
using System.Windows;
using ControlVentas;
using System.IO;
using System.Windows.Input;
using System.Collections;
using System.Collections.Generic;

namespace Hospital
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private CAdminPacientes admin;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Ingresar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string nombre = tB_Ingreso_Nombre.Text;
                string apellido = tB_Ingreso_Apellido.Text;
                string razon = tB_Ingreso_Razon.Text;
                string dpi = tB_DPI.Text;
                int dia = cB_Dia.SelectedIndex + 1;
                int mes = cB_Mes.SelectedIndex + 1;
                int year = int.Parse(tB_Year.Text);
                DateTime fechaNac = new DateTime(year, mes, dia);
                ETipoDeSangre sangre = (ETipoDeSangre)cB_Ingreso_Sangre.SelectedIndex;
                if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) || sangre == ETipoDeSangre.Cualquiera
                    || string.IsNullOrEmpty(dpi) || string.IsNullOrEmpty(tB_Year.Text))
                {
                    MessageBox.Show("Revisa los datos.");
                }
                else
                {
                    // ingresar paciente
                    CPaciente p = new CPaciente(nombre, apellido, dpi, fechaNac, razon, sangre);
                    admin.AgregarPaciente(p);
                    CUtilities.FillListView(lV_Pacientes, admin.BuscarPacientes(string.Empty, string.Empty, ETipoDeSangre.Cualquiera));
                    MessageBox.Show("El paciente ha sido agregado.");
                    // limpiar campos de ingreso
                    tB_Ingreso_Nombre.Text = string.Empty;
                    tB_Ingreso_Apellido.Text = string.Empty;
                    tB_DPI.Text = string.Empty;
                    tB_Year.Text = string.Empty;
                    cB_Dia.SelectedIndex = 0;
                    cB_Mes.SelectedIndex = 0;
                    cB_Ingreso_Sangre.SelectedIndex = 0;
                    tB_Ingreso_Razon.Text = string.Empty;
                }
            }
            catch(Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (!File.Exists(CUtilities.SAVE_FILE_NAME))
                File.Create(CUtilities.SAVE_FILE_NAME);
            admin = new CAdminPacientes();
            admin.Cargar();
            CUtilities.FillListView(lV_Pacientes, admin.BuscarPacientes(string.Empty, string.Empty, ETipoDeSangre.Cualquiera));
            cB_Ingreso_Sangre.SelectedIndex = 0;
            cB_Dia.SelectedIndex = 0;
            cB_Mes.SelectedIndex = 0;
        }

        private void btn_Buscar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string nombre = tB_Ingreso_Nombre.Text;
                string apellido = tB_Ingreso_Apellido.Text;
                ETipoDeSangre sangre = (ETipoDeSangre)cB_Ingreso_Sangre.SelectedIndex;
                CUtilities.FillListView(lV_Pacientes, admin.BuscarPacientes(nombre, apellido, sangre));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                admin.Guardar();
            }
            catch(Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btn_Ingreso_Eliminar_Click(object sender, RoutedEventArgs e)
        {
            if(lV_Pacientes.SelectedIndex >= 0)
            {
                try
                {
                    MessageBoxResult result = MessageBox.Show("Eliminar paciente?", "Confirmar",
                        MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                    if(result == MessageBoxResult.Yes)
                    {
                        admin.EliminarPaciente(lV_Pacientes.SelectedIndex);
                        CUtilities.FillListView(lV_Pacientes, admin.BuscarPacientes(string.Empty,
                            string.Empty, ETipoDeSangre.Cualquiera));
                    }
                }
                catch(Exception ex) { MessageBox.Show(ex.Message); }
            }
        }

        private void TextInputValidation(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !CUtilities.TextOnlyLetters(e.Text);
        }
        
        // *************** metodos para ordernar lista de pacientes **************
        private void SortLV(object sender, RoutedEventArgs e)
        {
            // una manera
            //GridViewColumnHeader headerClicked = e.OriginalSource as GridViewColumnHeader;
            //if(headerClicked != null)
            //{
            //    string sortBy = headerClicked.Content.ToString();
            //    sortBy = sortBy.ToLower();
            //    lV_Pacientes.Items.SortDescriptions.Clear();
            //    lV_Pacientes.Items.SortDescriptions.Add(new SortDescription(sortBy, ListSortDirection.Ascending));
            //}
        }

        // ordenar por nombres
        private void SortByName(object sender, RoutedEventArgs e)
        {
            lV_Pacientes.Items.Clear();
            IComparer<CPersona> comp = new CPersonaCompararNombre();
            admin.GetListaPacientes().Sort(comp);
            CUtilities.FillListView(lV_Pacientes, admin.GetListaPacientes());
        }
        // ordenar por apellidos
        private void SortByLastName(object sender, RoutedEventArgs e)
        {
            lV_Pacientes.Items.Clear();
            IComparer<CPersona> comp = new CPersonaCompararApellido();
            admin.GetListaPacientes().Sort(comp);
            CUtilities.FillListView(lV_Pacientes, admin.GetListaPacientes());
        }
        // ordenar por DPI
        private void SortByDPI(object sender, RoutedEventArgs e)
        {
            lV_Pacientes.Items.Clear();
            IComparer<CPersona> comp = new CPersonaCompararDPI();
            admin.GetListaPacientes().Sort(comp);
            CUtilities.FillListView(lV_Pacientes, admin.GetListaPacientes());
        }
        // ordenar por razon de ingreso
        private void SortByRazon(object sender, RoutedEventArgs e)
        {
            lV_Pacientes.Items.Clear();
            IComparer<CPaciente> comp = new CPersonaCompararRazon();
            admin.GetListaPacientes().Sort(comp);
            CUtilities.FillListView(lV_Pacientes, admin.GetListaPacientes());
        }
        //ordenar por edad
        private void SortByEdad(object sender, RoutedEventArgs e)
        {
            lV_Pacientes.Items.Clear();
            IComparer<CPaciente> comp = new CPersonaCompararEdad();
            admin.GetListaPacientes().Sort(comp);
            CUtilities.FillListView(lV_Pacientes, admin.GetListaPacientes());
        }
    }
}
