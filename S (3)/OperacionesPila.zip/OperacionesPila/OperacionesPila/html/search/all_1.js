var searchData=
[
  ['emptystackexception',['EmptyStackException',['../class_operaciones_pila_1_1_empty_stack_exception.html',1,'OperacionesPila']]]
];
