﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ControlVentas;

namespace Hospital
{
    public class CPaciente : CPersona
    {
        #region Private Variables
        public string razon { get; private set; }
        public ETipoDeSangre sangre { get; private set; }
        public string sangreS { get; private set; }
        #endregion

        #region Constructors
        public CPaciente(string nombre, string apellido, string dpi, DateTime f, string razon, ETipoDeSangre sangre)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.dpi = dpi;
            fechaNacimiento = f;
            this.razon = razon;
            this.sangre = sangre;
            this.sangreS = CUtilities.StringValueOf(sangre);
            CalcularEdad();
        }
        #endregion

        #region Public Methods
        public string GetRazon()
        {
            return razon;
        }

        public void SetRazon(string s)
        {
            razon = s;
        }

        public ETipoDeSangre GetSangre()
        {
            return sangre;
        }

        public void SetSangre(ETipoDeSangre s)
        {
            sangre = s;
        }

        public string GetSangreAsString()
        {
            return sangreS;
        }

        public string ToSaveString()
        {
            return nombre + "$" + apellido + "$" + dpi + "$" + fechaNacimiento.Year + "$" 
                + fechaNacimiento.Month + "$" + fechaNacimiento.Day + "$" + razon + "$" + (int)sangre + "$";
        }
        #endregion
    }
}
